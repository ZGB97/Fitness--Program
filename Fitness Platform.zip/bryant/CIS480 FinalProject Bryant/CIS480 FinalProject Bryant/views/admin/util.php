<?php

$key = '';

function uploadImages()
{

    // File upload configuration 
    $targetDir = "uploads/";
    $allowTypes = array('jpg', 'png', 'jpeg', 'gif');
    $paths = array();


    $fileNames = array_filter($_FILES['files']['name']);
    if (!empty($fileNames)) {
        foreach ($_FILES['files']['name'] as $key => $val) {
            // File upload path
            $file = explode(".", $_FILES["files"]["name"][$key]);
            $fileName = md5(microtime(true)) . '.' . end($file);
            $targetFilePath = $targetDir . $fileName;


            // Check whether file type is valid 
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
            // Check whether file type is valid 
            if (in_array($fileType, $allowTypes, true) && verifyMagicByte($_FILES["files"]["tmp_name"][$key])) {
                $imageTemp = $_FILES["files"]["tmp_name"][$key];
                $imageUploadPath = $targetDir . $fileName;
                $paths[] = compressImage($imageTemp, $imageUploadPath, 50);
            }
        }
    }
    return $paths;
}


function verifyMagicByte($file)
{
    // PNG, GIF, JFIF JPEG, EXIF JPEF respectively
    $allowed = array('89504E47', '47494638', 'FFD8FFE0', 'FFD8FFE1');
    $handle = fopen($file, 'r');
    $bytes = strtoupper(bin2hex(fread($handle, 4)));
    fclose($handle);
    return in_array($bytes, $allowed);
}

function removeExif($image)
{
    $img = new Imagick($image);
    $profiles = $img->getImageProfiles("icc", true);

    $img->stripImage();

    if (!empty($profiles))
        $img->profileImage("icc", $profiles['icc']);
}


function compressImage($source, $destination, $quality)
{
    // Get image info 
    $imgInfo = getimagesize($source);
    $mime = $imgInfo['mime'];

    // Create a new image from file 
    switch ($mime) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
        default:
            $image = imagecreatefromjpeg($source);
    }

    // Save image 
    imagejpeg($image, $destination, $quality);

    // Return compressed image 
    return $destination;
}
