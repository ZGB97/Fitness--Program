<?php

session_start();
require __DIR__ . '/db.php';

if (isset($_SESSION['name'])) {
    header('Location: /');
}

$error = false;
$errors = [];

if (isset($_POST['register'])) {
    if (strlen(filter_input(INPUT_POST, 'password')) < 6) {
        $errors['password'] = "Password must be at least 6 characters";
    }
    if (empty(filter_input(INPUT_POST, 'lastname', FILTER_SANITIZE_EMAIL))) {
        $errors['lastname'] = "Required field";
    }
    if (empty(filter_input(INPUT_POST, 'firstname', FILTER_SANITIZE_EMAIL))) {
        $errors['firstname'] = "Required field";
    }
    if (empty(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL))) {
        $errors['email'] = "Required field";
    }
    if (empty(filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_EMAIL))) {
        $errors['phone'] = "Required field";
    }
    if (empty(filter_input(INPUT_POST, 'address', FILTER_SANITIZE_EMAIL))) {
        $errors['address'] = "Required field";
    }

    if (count($errors) === 0) {
        $lastname = filter_input(INPUT_POST, 'lastname');
        $firstname = filter_input(INPUT_POST, 'firstname');
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $phone = filter_input(INPUT_POST, 'phone');
        $address = filter_input(INPUT_POST, 'address');
        $password = password_hash(filter_input(INPUT_POST, 'password'), PASSWORD_DEFAULT);
        $createdTime = time();

        $statement = $pdo->prepare("SELECT * FROM users WHERE email=?");
        $statement->execute(array($email));
        if ($statement->rowCount() > 0) {
            $error = true;
        } else {
            $statement = $pdo->prepare("INSERT INTO users (firstname, lastname, email, phone, address, password, created) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $statement->execute(array($firstname, $lastname, $email, $phone, $address, $password, $createdTime));
            session_start();
            $_SESSION['name'] = $lastname . ' ' . $firstname;
            $_SESSION['email'] = $email;
            $_SESSION['phone'] = $phone;
            $_SESSION['address'] = $address;
            $_SESSION['created-time'] = $createdTime;
            header('Location: /');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <!-- Basic Page Needs
  ================================================== -->
    <meta charset="utf-8">
    <title>Workout Shop - Best Fitness Programs</title>

    <!-- Mobile Specific Metas
  ================================================== -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="views/images/favicon.png" />

    <link rel="stylesheet" href="views/plugins/themefisher-font/style.css">
    <!-- bootstrap.min css -->
    <link rel="stylesheet" href="views/plugins/bootstrap/css/bootstrap.min.css">

    <!-- Animate css -->
    <link rel="stylesheet" href="views/plugins/animate/animate.css">
    <!-- Slick Carousel -->
    <link rel="stylesheet" href="views/plugins/slick/slick.css">
    <link rel="stylesheet" href="views/plugins/slick/slick-theme.css">

    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="views/css/style.css">

</head>

<body id="body">

    <section class="signin-page account">
        <div class="container">
            <div class="row">
                <?php if ($error) : ?>
                    <div class="row mt-30">
                        <div class="col-xs-12">
                            <div class="alertPart">
                                <div class="alert alert-danger alert-common" role="alert"><i class="tf-ion-close-circled"></i><span>Registration Failed!</span> Email already registered</div>
                            </div>
                        </div>
                    </div>
                <?php endif ?>
                <div class="col-md-6 col-md-offset-3">
                    <div class="block text-center">
                        <a href="/">
                            <?php require __DIR__ . '/logo.php'; ?>
                        </a>
                        <form class="text-left clearfix" method="post" action="<?= $_SERVER['REQUEST_URI'] ?>">
                            <div class="form-group">
                                <input type="text" name="firstname" class="form-control" placeholder="Firstname">
                                <?php echo isset($errors['firstname']) ? '<p style="color:red">' . $errors['firstname'] . '</p>' : '' ?>
                            </div>
                            <div class="form-group">
                                <input type="text" name="lastname" class="form-control" placeholder="Lastname">
                                <?php echo isset($errors['lastname']) ? '<p style="color:red">' . $errors['lastname'] . '</p>' : '' ?>
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control" placeholder="Email">
                                <?php echo isset($errors['email']) ? '<p style="color:red">' . $errors['email'] . '</p>' : '' ?>
                            </div>
                            <div class="form-group">
                                <input type="tel" name="phone" class="form-control" placeholder="Phone">
                                <?php echo isset($errors['phone']) ? '<p style="color:red">' . $errors['phone'] . '</p>' : '' ?>
                            </div>
                            <div class="form-group">
                                <input type="text" name="address" class="form-control" placeholder="Address">
                                <?php echo isset($errors['address']) ? '<p style="color:red">' . $errors['address'] . '</p>' : '' ?>
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" placeholder="Password">
                                <p style="font-size:14px">6 chars minimum</p>
                                <?php echo isset($errors['password']) ? '<p style="color:red">' . $errors['password'] . '</p>' : '' ?>
                            </div>
                            <div class="text-center">
                                <button name="register" type="submit" class="btn btn-main text-center">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 
    Essential Scripts
    =====================================-->

    <!-- Main jQuery -->
    <script src="views/plugins/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap 3.1 -->
    <script src="views/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap Touchpin -->
    <script src="views/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js"></script>
    <!-- Video Lightbox Plugin -->
    <script src="views/plugins/ekko-lightbox/dist/ekko-lightbox.min.js"></script>
    <!-- Count Down Js -->
    <script src="views/plugins/syo-timer/build/jquery.syotimer.min.js"></script>

    <!-- slick Carousel -->
    <script src="views/plugins/slick/slick.min.js"></script>
    <script src="views/plugins/slick/slick-animation.min.js'"></script>

    <!-- Main Js File -->
    <script src="views/js/script.js"></script>



</body>

</html>